import control from './control.js';

const root =document.getElementById('root');
const main = new control(root)